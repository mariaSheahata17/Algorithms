import UIKit

/*

 
 /* to chekc if the sorting is right

 */
 
 Steps:
 1. Make a dictionary, key is people and the value is list of their prefrences brands
 2. Make a nother dictionary, key is people and the value is the number of their prefrences brands
 3. Sort the second dictionary based of the value, from smallest to largest
 4. create the list of available brands
 5. start the matching process
 
*/




var brands = ["A","B","C","D","E"]
var prefrences = [1:["A","B"], 2:["C","D"], 3:["C"], 4:["E"],5:["D","E"], 6:["A","B"]]
var prefrencesNumbers : [Int : Int] = [:]

for (key, value) in prefrences{
    prefrencesNumbers[key] = value.count
    print(key , prefrencesNumbers[key])
}

var sortedPeople = Array(prefrencesNumbers.keys)
var sortedKeys = sortedPeople.sort() {
    var obj1 = prefrencesNumbers[$0] // get ob associated w/ key 1
    var obj2 = prefrencesNumbers[$1] // get ob associated w/ key 2
    return obj1! < obj2!
}

// check sorting
print(" people sorted by the least number of prefrences")
for person in sortedPeople{
    print(person)
}

//start the matching process
print("######Solution######")
for person in sortedPeople{
    for prefrence in prefrences[person]!{
        if brands.contains(prefrence) {
            print("person", person, "will take brand: ", prefrence )
            if let index = brands.firstIndex(of: prefrence) {
                brands.remove(at: index)
            }
            break
        }
            
    }
}
